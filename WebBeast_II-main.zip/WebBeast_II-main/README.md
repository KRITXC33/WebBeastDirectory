#WebBeast II

#What is WBII?
The second WB is dedicated to Python, where the first was a website, using HTML, CSS, and JS.
