var app = (function () {
    /* Properties */
    var websiteName = "kdcodes"
    /*Methods*/
    return {
        getWebsiteName: function () {
            return websiteName;
        }
    }
} ();
