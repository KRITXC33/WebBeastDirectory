Add common.js
